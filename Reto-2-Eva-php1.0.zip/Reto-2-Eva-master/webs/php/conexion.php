<?php
// Datos de conexión
$host = "localhost";
$usuario = "root"; // Cambiar si es necesario
$password = ""; // Cambiar si es necesario
$base_datos = "agencia_alquiler";

// Crear conexión
$conn = new mysqli($host, $usuario, $password, $base_datos);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Establecer charset a UTF-8
$conn->set_charset("utf8");
?>
