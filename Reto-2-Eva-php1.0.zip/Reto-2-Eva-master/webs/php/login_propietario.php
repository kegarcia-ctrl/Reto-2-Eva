<?php
session_start();
require 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Buscar usuario que sea ADMIN (propietario)
    $sql = "SELECT id, nombre_completo, password, rol FROM usuarios WHERE email = '$email' AND rol = 'admin'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Login correcto
            $_SESSION['usuario_id'] = $row['id'];
            $_SESSION['nombre'] = $row['nombre_completo'];
            $_SESSION['rol'] = $row['rol'];

            // Redirigir al panel de propietario
            echo "<script>window.location.href='../propietario.html';</script>";
        } else {
            echo "<script>alert('Contraseña incorrecta.'); window.location.href='../web.html#login-owner';</script>";
        }
    } else {
        // Verificar si existe el usuario pero no es admin
        $checkUser = "SELECT id FROM usuarios WHERE email = '$email'";
        $resUser = $conn->query($checkUser);
        if ($resUser->num_rows > 0) {
            echo "<script>alert('No tienes permisos de propietario.'); window.location.href='../web.html#login-owner';</script>";
        } else {
            echo "<script>alert('Usuario no encontrado.'); window.location.href='../web.html#login-owner';</script>";
        }
    }
}

$conn->close();
?>