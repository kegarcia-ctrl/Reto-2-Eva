<?php
require 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encriptar contraseña
    $rol = 'cliente'; // Por defecto, es cliente

    // Verificar si el correo ya existe
    $checkEmail = "SELECT id FROM usuarios WHERE email = '$email'";
    $result = $conn->query($checkEmail);

    if ($result->num_rows > 0) {
        echo "<script>alert('El correo ya está registrado.'); window.location.href='../web.html#registro';</script>";
    } else {
        // Insertar nuevo usuario
        $sql = "INSERT INTO usuarios (nombre_completo, email, password, rol) VALUES ('$nombre', '$email', '$password', '$rol')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Registro exitoso. Por favor inicia sesión.'); window.location.href='../web.html#login';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>