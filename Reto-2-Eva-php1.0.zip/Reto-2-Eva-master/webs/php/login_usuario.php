<?php
session_start();
require 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT id, nombre_completo, password, rol FROM usuarios WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Contraseña correcta
            $_SESSION['usuario_id'] = $row['id'];
            $_SESSION['nombre'] = $row['nombre_completo'];
            $_SESSION['rol'] = $row['rol'];

            // Redirigir según el rol? O simplemente al home
            // Si es admin intentando entrar por login normal, también va al home por ahora
            echo "<script>window.location.href='../web.html';</script>";
        } else {
            echo "<script>alert('Contraseña incorrecta.'); window.location.href='../web.html#login';</script>";
        }
    } else {
        echo "<script>alert('No existe una cuenta con este correo.'); window.location.href='../web.html#login';</script>";
    }
}

$conn->close();
?>